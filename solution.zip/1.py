from flask import Flask
from data import db_session
from data.__all_models import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/users.db")

    db_sess = db_session.create_session()

    user1 = User()
    user1.name = 'Scott'
    user1.surname = 'Ridley'
    user1.age = 21
    user1.position = 'captain'
    user1.speciality = 'research engineer'
    user1.address = 'module_1'
    user1.email = 'scott_chief@mars.org'
    db_sess.add(user1)

    user2 = User()
    user2.name = 'Lady'
    user2.surname = 'Gaga'
    user2.age = 34
    user2.position = 'teammate'
    user2.speciality = 'singer'
    user2.address = 'module_2'
    user2.email = 'ladygaga@mars.org'
    db_sess.add(user2)

    user3 = User()
    user3.name = 'Elizabeth'
    user3.surname = 'The Second'
    user3.age = 94
    user3.position = 'queen'
    user3.speciality = 'queen'
    user3.address = 'module_3'
    user3.email = 'elizabeth2@mars.org'
    db_sess.add(user3)

    user4 = User()
    user4.name = 'X AE A-12'
    user4.surname = 'Musk'
    user4.age = 0
    user4.position = 'teammate'
    user4.speciality = 'baby'
    user4.address = 'module_4'
    user4.email = 'musk@mars.org'
    db_sess.add(user4)

    db_sess.commit()

    # app.run()


if __name__ == '__main__':
    main()
